import os
import joblib

def inspect_email(raw_email_string):
    """
    Loads runtime production models to test a live string sample 
    for fraudulent threat indicators.
    """
    model_path = os.path.join("models", "phishing_model.pkl")
    pipeline_path = os.path.join("models", "feature_pipeline.pkl")
    
    if not (os.path.exists(model_path) and os.path.exists(pipeline_path)):
        return "Error: Serialized model files missing. Please run 'train_model.py' first.", None

    # Load artifacts
    classifier = joblib.load(model_path)
    extractor = joblib.load(pipeline_path)

    # Convert text to feature vector
    extracted_features = extractor.transform([raw_email_string])
    
    # Predict label and probabilities
    prediction_id = classifier.predict(extracted_features)[0]
    probabilities = classifier.predict_proba(extracted_features)[0]

    result_label = "PHISHING EMAIL" if prediction_id == 1 else "SAFE EMAIL"
    
    probability_distribution = {
        "Safe Probability": probabilities[0] * 100,
        "Phishing Probability": probabilities[1] * 100
    }
    
    return result_label, probability_distribution

if __name__ == "__main__":
    print("--- Runtime Phishing Scanner Terminal App ---")
    sample_input = input("\nEnter Raw Email Content to Inspect:\n> ")
    
    label, probs = inspect_email(sample_input)
    
    if probs is None:
        print(label)
    else:
        print("\n" + "="*40)
        print(f" SCAN RESULT: {label}")
        print("="*40)
        print(f" Phishing Probability : {probs['Phishing Probability']:.2f}%")
        print(f" Safe Probability     : {probs['Safe Probability']:.2f}%")
        print("="*40)