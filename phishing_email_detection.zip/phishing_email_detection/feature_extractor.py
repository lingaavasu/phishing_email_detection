import re
import pandas as pd
import numpy as np
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.feature_extraction.text import TfidfVectorizer

class EmailFeatureExtractor(BaseEstimator, TransformerMixin):
    """
    Custom Scikit-Learn Transformer that extracts structural, text-metric, 
    and engineered URL features alongside TF-IDF vectors from raw email text.
    """
    def __init__(self, max_features=1000):
        self.max_features = max_features
        # Extract both single words and word pairs
        self.tfidf = TfidfVectorizer(max_features=self.max_features, ngram_range=(1, 2))
        
        # Keywords to flag
        self.suspicious_domains = ['login', 'verify', 'update', 'confirm', 'bank', 'secure', 'account', 'password', 'paypal', 'signin']
        self.urgent_words = ['urgent', 'immediately', 'act now', 'limited time', 'winner', 'congratulations', 'free', 'claim']

    def _extract_meta_features(self, raw_text):
        """Helper to compute engineering metrics from a single raw text string."""
        if not isinstance(raw_text, str):
            raw_text = ""
            
        # URL detection regex
        urls = re.findall(r'https?://[^\s]+|www\.[^\s]+', raw_text)
        num_urls = len(urls)
        
        # Analyze URLs if present
        num_suspicious_urls = 0
        has_ip_url = 0
        total_dots = 0
        total_url_len = 0
        has_http = 0
        
        for url in urls:
            total_url_len += len(url)
            total_dots += url.count('.')
            if 'http://' in url:
                has_http = 1
            # Check for IP address patterns in URL
            if re.search(r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}', url):
                has_ip_url = 1
            # Scan for malicious domain indicators
            if any(kw in url.lower() for kw in self.suspicious_domains):
                num_suspicious_urls += 1

        # Email content metrics
        num_uppercase = len(re.findall(r'\b[A-Z]{2,}\b', raw_text))
        num_exclamation = raw_text.count('!')
        num_dollar = raw_text.count('$')
        
        has_urgent = 0
        if any(word in raw_text.lower() for word in self.urgent_words):
            has_urgent = 1

        return [
            num_urls, num_suspicious_urls, has_ip_url, total_dots,
            total_url_len, has_http, num_uppercase, num_exclamation,
            num_dollar, has_urgent
        ]

    def fit(self, X, y=None):
        # Clean text specifically for the underlying textual TF-IDF matrix
        cleaned_corpus = [re.sub(r'[^\w\s]', '', str(text).lower()) for text in X]
        self.tfidf.fit(cleaned_corpus)
        return self

    def transform(self, X):
        # 1. Generate textual features
        cleaned_corpus = [re.sub(r'[^\w\s]', '', str(text).lower()) for text in X]
        tfidf_matrix = self.tfidf.transform(cleaned_corpus).toarray()
        
        # 2. Generate engineered structural/URL features
        meta_features = [self._extract_meta_features(text) for text in X]
        meta_matrix = np.array(meta_features)
        
        # Concatenate text features and metadata side-by-side
        return np.hstack((tfidf_matrix, meta_matrix))