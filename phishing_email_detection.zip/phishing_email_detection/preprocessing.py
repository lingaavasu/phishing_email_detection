import re

def clean_text(text):
    """
    Cleans raw email text by converting to lowercase, removing punctuation,
    and trimming spaces.
    """
    if not isinstance(text, str):
        return ""
    
    # 1. Convert to lowercase
    text = text.lower()
    
    # 2. Remove unnecessary whitespace/newlines
    text = re.sub(r'\s+', ' ', text).strip()
    
    # 3. Remove punctuation (leaving spaces and alphanumeric characters)
    text = re.sub(r'[^\w\s]', '', text)
    
    return text