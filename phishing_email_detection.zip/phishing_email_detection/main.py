import os
import sys

def execute_system():
    print("====================================================")
    print("  MALICIOUS PHISHING EMAIL ML CLASSIFIER SYSTEM  ")
    print("====================================================\n")
    print("1. Initialize Training & Benchmark Evaluation Pipeline")
    print("2. Launch Live Interactive Prediction System")
    print("3. Exit Application")
    
    selection = input("\nSelect Operational Path (1-3): ").strip()
    
    if selection == '1':
        import train_model
        train_model.train_pipeline()
    elif selection == '2':
        import predict
        print("\nLaunching runtime terminal instance...")
        # Simulates terminal interaction loop
        model_path = os.path.join("models", "phishing_model.pkl")
        if not os.path.exists(model_path):
            print("[ALERT] Model has not been trained yet. Running training step first...")
            import train_model
            train_model.train_pipeline()
            
        print("\nEnter custom email blocks below to evaluate risk profile:")
        raw_input = input("\nEmail Text:\n> ")
        label, probs = predict.inspect_email(raw_input)
        print(f"\nPrediction Outcome: {label}")
        if probs:
            print(f"Metrics breakdown -> Phishing: {probs['Phishing Probability']:.2f}% | Safe: {probs['Safe Probability']:.2f}%")
    else:
        print("[INFO] Terminating System instance safely.")
        sys.exit(0)

if __name__ == "__main__":
    execute_system()