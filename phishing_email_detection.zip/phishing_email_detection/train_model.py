import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import joblib

from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report, confusion_matrix

#  CORRECT 
from feature_extractor import EmailFeatureExtractor

def train_pipeline():
    print("--- Phishing Email Detection Training Initialization ---")
    
    # 1. Load Dataset
    csv_path = os.path.join("dataset", "emails.csv")
    if not os.path.exists(csv_path):
        raise FileNotFoundError(f"Missing dataset profile at {csv_path}. Populate this file first.")
        
    df = pd.read_csv(csv_path)
    print(f"[INFO] Dataset Loaded successfully. Records: {len(df)}")
    
    # Drop rows missing critical variables
    df = df.dropna(subset=['label', 'email'])
    
    X = df['email'].values
    # Convert nominal classes to binaries (phishing -> 1, safe -> 0)
    y = df['label'].map({'phishing': 1, 'safe': 0}).values

    # 2. Extract Features
    print("[INFO] Engineering hybrid text and structural metadata features...")
    extractor = EmailFeatureExtractor(max_features=500)
    X_features = extractor.fit_transform(X)

    # 3. Train-Test Split
    X_train, X_test, y_train, y_test = train_test_split(
        X_features, y, test_size=0.20, random_state=42, stratify=y
    )

    # 4. Compare Classifiers
    models = {
        "Logistic Regression": LogisticRegression(max_iter=1000),
        "Random Forest": RandomForestClassifier(n_estimators=100, random_state=42)
    }
    
    best_model = None
    best_score = -1
    best_name = ""

    print("\n--- Model Benchmark ---")
    for name, clf in models.items():
        # Validate model variance via cross-validation
        cv_scores = cross_val_score(clf, X_train, y_train, cv=3, scoring='accuracy')
        clf.fit(X_train, y_train)
        preds = clf.predict(X_test)
        acc = accuracy_score(y_test, preds)
        
        print(f"{name} -> Cross-Val Acc: {cv_scores.mean():.4f} | Test Acc: {acc:.4f}")
        
        if acc > best_score:
            best_score = acc
            best_model = clf
            best_name = name

    print(f"\n[SUCCESS] Best Algorithm Chosen: {best_name} ({best_score*100:.2f}% Test Accuracy)")

    # 5. Full Evaluation Metrics
    final_preds = best_model.predict(X_test)
    print("\n--- Detailed Classification Report ---")
    print(classification_report(y_test, final_preds, target_names=['Safe', 'Phishing']))

    # Generate explicit variables for reporting metrics
    print(f"Accuracy  : {accuracy_score(y_test, final_preds):.4f}")
    print(f"Precision : {precision_score(y_test, final_preds):.4f}")
    print(f"Recall    : {recall_score(y_test, final_preds):.4f}")
    print(f"F1 Score  : {f1_score(y_test, final_preds):.4f}\n")

    # 6. Render Confusion Matrix
    cm = confusion_matrix(y_test, final_preds)
    plt.figure(figsize=(5, 4))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                xticklabels=['Predicted Safe', 'Predicted Phishing'],
                yticklabels=['Actual Safe', 'Actual Phishing'])
    plt.title(f"Confusion Matrix - {best_name}")
    plt.ylabel('True Classification')
    plt.xlabel('Predicted Classification')
    
    os.makedirs("models", exist_ok=True)
    matrix_img_path = os.path.join("models", "confusion_matrix.png")
    plt.savefig(matrix_img_path)
    print(f"[INFO] Plot matrix configuration exported visually to {matrix_img_path}")
    plt.close()

    # 7. Persist Pipeline & Model Files
    joblib.dump(best_model, os.path.join("models", "phishing_model.pkl"))
    joblib.dump(extractor, os.path.join("models", "feature_pipeline.pkl"))
    print("[SUCCESS] Production artifacts successfully saved down into /models/")

if __name__ == "__main__":
    train_pipeline()